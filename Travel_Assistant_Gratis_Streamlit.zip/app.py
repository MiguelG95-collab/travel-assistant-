
import math
from datetime import datetime
from zoneinfo import ZoneInfo

import folium
import pandas as pd
import requests
import streamlit as st
from streamlit_folium import st_folium

st.set_page_config(page_title="Travel Assistant Gratis", page_icon="✈️", layout="wide")
UA = "TravelAssistantGratis/1.0"
OVERPASS = ["https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"]

@st.cache_data(ttl=86400)
def geocode(name):
    r = requests.get(
        "https://geocoding-api.open-meteo.com/v1/search",
        params={"name": name, "count": 8, "language": "es", "format": "json"},
        headers={"User-Agent": UA}, timeout=20
    )
    r.raise_for_status()
    return r.json().get("results", [])

@st.cache_data(ttl=1800)
def weather(lat, lon, tz):
    r = requests.get(
        "https://api.open-meteo.com/v1/forecast",
        params={
            "latitude": lat, "longitude": lon, "timezone": tz,
            "current": "temperature_2m,apparent_temperature,weather_code,wind_speed_10m"
        },
        headers={"User-Agent": UA}, timeout=20
    )
    r.raise_for_status()
    return r.json().get("current", {})

def condition(code):
    return {
        0:"Despejado",1:"Mayormente despejado",2:"Parcialmente nublado",3:"Nublado",
        45:"Niebla",51:"Llovizna",61:"Lluvia ligera",63:"Lluvia",65:"Lluvia intensa",
        71:"Nieve ligera",73:"Nieve",80:"Chubascos",81:"Chubascos",
        95:"Tormenta",96:"Tormenta con granizo"
    }.get(code, "Variable")

def haversine(a,b,c,d):
    r=6371
    p1,p2=math.radians(a),math.radians(c)
    dp,dl=math.radians(c-a),math.radians(d-b)
    x=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*r*math.asin(math.sqrt(x))

@st.cache_data(ttl=3600)
def get_pois(lat, lon, radius):
    q=f"""
    [out:json][timeout:40];
    (
      nwr(around:{radius},{lat},{lon})["tourism"~"hotel|hostel|guest_house|apartment|motel"];
      nwr(around:{radius},{lat},{lon})["amenity"~"restaurant|cafe|fast_food|bar"];
      nwr(around:{radius},{lat},{lon})["tourism"~"attraction|museum|gallery|viewpoint|zoo|theme_park"];
      nwr(around:{radius},{lat},{lon})["historic"];
      nwr(around:{radius},{lat},{lon})["railway"~"station|subway_entrance|tram_stop"];
      nwr(around:{radius},{lat},{lon})["amenity"="bus_station"];
      nwr(around:{radius},{lat},{lon})["aeroway"="aerodrome"];
    );
    out center tags;
    """
    last=None
    for endpoint in OVERPASS:
        try:
            r=requests.post(endpoint,data={"data":q},headers={"User-Agent":UA},timeout=60)
            r.raise_for_status()
            return r.json().get("elements",[])
        except Exception as e:
            last=e
    raise RuntimeError(last)

def parse(elements, lat0, lon0):
    rows=[]
    for e in elements:
        t=e.get("tags",{})
        lat=e.get("lat") or e.get("center",{}).get("lat")
        lon=e.get("lon") or e.get("center",{}).get("lon")
        if lat is None or lon is None: continue
        tourism=t.get("tourism","")
        amenity=t.get("amenity","")
        railway=t.get("railway","")
        historic=t.get("historic","")
        aeroway=t.get("aeroway","")
        if tourism in {"hotel","hostel","guest_house","apartment","motel"}:
            cat="Hoteles"; typ=tourism
        elif amenity in {"restaurant","cafe","fast_food","bar"}:
            cat="Restaurantes"; typ=amenity
        elif tourism in {"attraction","museum","gallery","viewpoint","zoo","theme_park"} or historic:
            cat="Lugares para visitar"; typ=tourism or historic
        elif railway or amenity=="bus_station" or aeroway=="aerodrome":
            cat="Transporte"; typ=railway or amenity or aeroway
        else:
            continue
        try:
            star=int(float(str(t.get("stars") or t.get("hotel:stars")).replace(",",".")))
        except:
            star=None
        address=" ".join(str(x) for x in [
            t.get("addr:street"),t.get("addr:housenumber"),t.get("addr:city")
        ] if x)
        rows.append({
            "Categoría":cat,
            "Nombre":t.get("name") or t.get("brand") or "Sin nombre registrado",
            "Tipo":typ.replace("_"," ").title(),
            "Estrellas":star,
            "Cocina":t.get("cuisine","").replace(";",", "),
            "Teléfono":t.get("contact:phone") or t.get("phone") or "",
            "Horario":t.get("opening_hours",""),
            "Sitio web":t.get("contact:website") or t.get("website") or "",
            "Dirección":address,
            "Distancia km":round(haversine(lat0,lon0,lat,lon),2),
            "Latitud":lat,"Longitud":lon,
            "Mapa":f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=17/{lat}/{lon}"
        })
    return pd.DataFrame(rows).drop_duplicates() if rows else pd.DataFrame()

def table(df, cols):
    if df.empty:
        st.info("No se encontraron resultados registrados.")
    else:
        st.dataframe(
            df[cols], use_container_width=True, hide_index=True,
            column_config={
                "Sitio web":st.column_config.LinkColumn("Sitio web",display_text="Abrir"),
                "Mapa":st.column_config.LinkColumn("Mapa",display_text="Ver"),
                "Distancia km":st.column_config.NumberColumn("Distancia km",format="%.2f")
            }
        )

st.title("✈️ Travel Assistant Gratis")
st.caption("Buscador de destinos para agencias de viajes, sin Google Places ni tarjeta bancaria.")

with st.sidebar:
    radius=st.slider("Radio de búsqueda (km)",2,20,8)
    limit=st.slider("Resultados por sección",10,80,30,10)
    st.info("Fuentes abiertas: Open-Meteo y OpenStreetMap.")

q=st.text_input("Ciudad o destino",placeholder="Madrid, España")
if st.button("Buscar",type="primary",use_container_width=True) and q.strip():
    st.session_state["cities"]=geocode(q.strip())

cities=st.session_state.get("cities",[])
if not cities:
    st.markdown("Busca una ciudad para consultar hora, clima, hoteles, restaurantes, atractivos, transporte, distancias y mapa.")
    st.stop()

opts={", ".join(filter(None,[c.get("name"),c.get("admin1"),c.get("country")])):c for c in cities}
label=st.selectbox("Selecciona la ubicación correcta",list(opts))
c=opts[label]
lat,lon=float(c["latitude"]),float(c["longitude"])
tz=c.get("timezone") or "UTC"
name=c.get("name",label)
country=c.get("country","")

local=datetime.now(ZoneInfo(tz))
mx=datetime.now(ZoneInfo("America/Mexico_City"))
diff=(local.utcoffset()-mx.utcoffset()).total_seconds()/3600

a,b,d,e=st.columns(4)
a.metric("Hora local",local.strftime("%H:%M"))
b.metric("Fecha",local.strftime("%d/%m/%Y"))
d.metric("Diferencia con CDMX",f"{diff:+g} h")
e.metric("Zona horaria",tz)

try:
    w=weather(lat,lon,tz)
    a,b,d,e=st.columns(4)
    a.metric("Temperatura",f"{w.get('temperature_2m','—')} °C")
    b.metric("Sensación",f"{w.get('apparent_temperature','—')} °C")
    d.metric("Clima",condition(w.get("weather_code")))
    e.metric("Viento",f"{w.get('wind_speed_10m','—')} km/h")
except Exception as exc:
    st.warning(f"No se pudo cargar el clima: {exc}")

try:
    with st.spinner("Reuniendo información del destino..."):
        data=parse(get_pois(lat,lon,radius*1000),lat,lon).sort_values("Distancia km")
except Exception as exc:
    st.error(f"No fue posible consultar los lugares: {exc}")
    data=pd.DataFrame()

tabs=st.tabs(["🏨 Hoteles","🍽️ Restaurantes","📍 Visitar","🚇 Transporte","🗺️ Mapa","📥 Exportar"])

with tabs[0]:
    x=data[data["Categoría"]=="Hoteles"].head(limit) if not data.empty else pd.DataFrame()
    table(x,["Nombre","Tipo","Estrellas","Teléfono","Sitio web","Dirección","Distancia km","Mapa"] if not x.empty else [])
with tabs[1]:
    x=data[data["Categoría"]=="Restaurantes"].head(limit) if not data.empty else pd.DataFrame()
    table(x,["Nombre","Tipo","Cocina","Teléfono","Horario","Sitio web","Dirección","Distancia km","Mapa"] if not x.empty else [])
with tabs[2]:
    x=data[data["Categoría"]=="Lugares para visitar"].head(limit) if not data.empty else pd.DataFrame()
    table(x,["Nombre","Tipo","Dirección","Distancia km","Sitio web","Mapa"] if not x.empty else [])
with tabs[3]:
    x=data[data["Categoría"]=="Transporte"].head(limit) if not data.empty else pd.DataFrame()
    table(x,["Nombre","Tipo","Dirección","Distancia km","Mapa"] if not x.empty else [])
with tabs[4]:
    m=folium.Map(location=[lat,lon],zoom_start=13)
    folium.Marker([lat,lon],tooltip=f"Centro de {name}").add_to(m)
    if not data.empty:
        for _,r in data.head(250).iterrows():
            folium.Marker([r["Latitud"],r["Longitud"]],tooltip=r["Nombre"],popup=f"{r['Categoría']} · {r['Distancia km']} km").add_to(m)
    st_folium(m,height=600,use_container_width=True)
with tabs[5]:
    clean=data.drop(columns=["Latitud","Longitud"],errors="ignore") if not data.empty else pd.DataFrame()
    st.download_button(
        "Descargar resultados CSV",
        clean.to_csv(index=False).encode("utf-8-sig"),
        f"{name}_destino.csv".replace(" ","_"),
        "text/csv",
        use_container_width=True
    )

st.caption("La disponibilidad de teléfonos, estrellas y horarios depende de los datos registrados en OpenStreetMap.")
