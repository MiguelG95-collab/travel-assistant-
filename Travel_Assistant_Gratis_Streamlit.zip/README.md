# Travel Assistant Gratis

## Publicarlo gratis y obtener un link

1. Crea una cuenta gratuita en GitHub.
2. Crea un repositorio llamado `travel-assistant-gratis`.
3. Sube `app.py` y `requirements.txt`.
4. Entra a Streamlit Community Cloud con tu cuenta de GitHub.
5. Pulsa **Create app**.
6. Selecciona el repositorio y usa `app.py` como archivo principal.
7. Pulsa **Deploy**.

Obtendrás un enlace parecido a:

`https://travel-assistant-gratis.streamlit.app`

## Ejecutarlo localmente

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Importante

Esta versión no requiere Google, tarjeta ni API de pago.
Los datos vienen de OpenStreetMap y Open-Meteo.
No incluye disponibilidad o precios hoteleros en tiempo real.
